var searchData=
[
  ['result_5fcommand',['result_command',['../struct__Game.html#ab6b04f339d8c214112366e3207164ebb',1,'_Game']]],
  ['result_5fprev_5fcommand',['result_prev_command',['../struct__Game.html#a9b1ff5315a1aeb3b0c66007da129f57a',1,'_Game']]]
];
