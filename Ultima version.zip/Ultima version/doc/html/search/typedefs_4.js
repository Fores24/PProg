var searchData=
[
  ['id',['Id',['../types_8h.html#a845e604fb28f7e3d97549da3448149d3',1,'types.h']]],
  ['inventory',['Inventory',['../inventory_8h.html#a2253bf64ac4ce6a9c1d6f39c0b0d32a3',1,'inventory.h']]]
];
