var searchData=
[
  ['ok',['OK',['../types_8h.html#a32c27cc471df37f4fc818d65de0a56c4a2bc49ec37d6a5715dd23e85f1ff5bb59',1,'types.h']]],
  ['open',['OPEN',['../command_8h.html#ace19ba2296a74e4aef53304e0934c50ca0e0143636c29971736eab47415868eae',1,'command.h']]]
];
