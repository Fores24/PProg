var searchData=
[
  ['name',['name',['../struct__Command.html#a08f9c6b984243b637887e0bf0c50bd7e',1,'_Command::name()'],['../struct__Link.html#a5d81b67643f9c41056d8b199adbed77d',1,'_Link::name()'],['../struct__Object.html#a3dab853826b88558a2c07dec50b96d57',1,'_Object::name()'],['../struct__Player.html#adda99df91c28eb58d392f2b43fc6898f',1,'_Player::name()'],['../struct__Space.html#aa1c9c994c2d16ecf3ef46138685fdfdc',1,'_Space::name()']]],
  ['north',['north',['../struct__Space.html#ae5ebe53ce79514d7d2d93911e0159252',1,'_Space']]],
  ['num_5fobj',['num_obj',['../struct__Set.html#a6d4c5bc1c085564602a0e93fe074ad91',1,'_Set']]]
];
