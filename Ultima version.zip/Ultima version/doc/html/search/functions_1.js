var searchData=
[
  ['dialogue_5faction',['dialogue_action',['../dialogue_8c.html#a75c574c3478c2a41ed3b1a11ee70d9ed',1,'dialogue_action(Command *command, T_Command prev_cmd, STATUS prev_stat, STATUS act_stat, char *aux):&#160;dialogue.c'],['../dialogue_8h.html#a75c574c3478c2a41ed3b1a11ee70d9ed',1,'dialogue_action(Command *command, T_Command prev_cmd, STATUS prev_stat, STATUS act_stat, char *aux):&#160;dialogue.c']]],
  ['die_5fcreate',['die_create',['../die_8c.html#a7edfb04683a77471c710342df00b7562',1,'die_create():&#160;die.c'],['../die_8h.html#a7edfb04683a77471c710342df00b7562',1,'die_create():&#160;die.c']]],
  ['die_5fdestroy',['die_destroy',['../die_8c.html#a0155d7ec003966bace47f3e032a368e8',1,'die_destroy(Die *die):&#160;die.c'],['../die_8h.html#a0155d7ec003966bace47f3e032a368e8',1,'die_destroy(Die *die):&#160;die.c']]],
  ['die_5fget_5fid',['die_get_id',['../die_8c.html#a57c9a2627bb3a1ca04fe55d72bd6a5ea',1,'die_get_id(Die *die):&#160;die.c'],['../die_8h.html#a57c9a2627bb3a1ca04fe55d72bd6a5ea',1,'die_get_id(Die *die):&#160;die.c']]],
  ['die_5fget_5flast_5froll',['die_get_last_roll',['../die_8c.html#a9347ed79daba7e8078611d67a52e1bfb',1,'die_get_last_roll(Die *die):&#160;die.c'],['../die_8h.html#a9347ed79daba7e8078611d67a52e1bfb',1,'die_get_last_roll(Die *die):&#160;die.c']]],
  ['die_5fprint',['die_print',['../die_8c.html#adb0fa0ace96ca78efc3c0b191293e005',1,'die_print(FILE *f, Die *die):&#160;die.c'],['../die_8h.html#adb0fa0ace96ca78efc3c0b191293e005',1,'die_print(FILE *f, Die *die):&#160;die.c']]],
  ['die_5froll',['die_roll',['../die_8c.html#a06289514edbedf660c4b043f78e859fc',1,'die_roll(Die *die):&#160;die.c'],['../die_8h.html#a06289514edbedf660c4b043f78e859fc',1,'die_roll(Die *die):&#160;die.c']]],
  ['die_5fset_5fid',['die_set_id',['../die_8c.html#a9062d99f612a9779903e9856c96db9d4',1,'die_set_id(Die *die, Id id):&#160;die.c'],['../die_8h.html#a9062d99f612a9779903e9856c96db9d4',1,'die_set_id(Die *die, Id id):&#160;die.c']]]
];
