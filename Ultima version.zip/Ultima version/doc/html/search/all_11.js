var searchData=
[
  ['reset',['RESET',['../test_8h.html#ab702106cf3b3e96750b6845ded4e0299',1,'test.h']]],
  ['result_5fcommand',['result_command',['../struct__Game.html#ab6b04f339d8c214112366e3207164ebb',1,'_Game']]],
  ['result_5fprev_5fcommand',['result_prev_command',['../struct__Game.html#a9b1ff5315a1aeb3b0c66007da129f57a',1,'_Game']]],
  ['roll',['ROLL',['../command_8h.html#ace19ba2296a74e4aef53304e0934c50ca2eeb9fef8a6a516fa6437a44a6efbd52',1,'command.h']]],
  ['rows',['ROWS',['../screen_8c.html#a3cfd3aa62338d12609f6d65bce97e9cd',1,'screen.c']]]
];
