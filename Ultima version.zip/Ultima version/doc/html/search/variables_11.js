var searchData=
[
  ['up',['up',['../struct__Space.html#af2a50145d93dfb8d82b8b42138dc57a1',1,'_Space']]]
];
