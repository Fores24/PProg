var searchData=
[
  ['object',['object',['../struct__Game.html#a8ade6d831e4710c40b0d61004bbd1585',1,'_Game']]],
  ['objects',['objects',['../struct__Inventory.html#a478e4b50a62b9e7d5b17e335319faa97',1,'_Inventory::objects()'],['../struct__Space.html#a661ed8b0fc8085b6db70188aa5085625',1,'_Space::objects()']]],
  ['on',['on',['../struct__Object.html#a325dedec5324e588d2a86e7ffa478350',1,'_Object']]],
  ['open',['open',['../struct__Object.html#a0922dd9891e6aa617ce1d51ae27c0175',1,'_Object']]],
  ['original_5flocation',['original_location',['../struct__Object.html#a70df2bf7a3fa2b9b20bd3a20afb2ac26',1,'_Object']]]
];
