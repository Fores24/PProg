var searchData=
[
  ['west',['west',['../struct__Space.html#a20c1d259e93b44e24ba82982e142eb9b',1,'_Space']]],
  ['width',['width',['../struct__Area.html#aa2f753fc3d254821603ac4512db814f1',1,'_Area']]]
];
