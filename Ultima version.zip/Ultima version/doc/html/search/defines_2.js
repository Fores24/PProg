var searchData=
[
  ['cmd_5flenght',['CMD_LENGHT',['../command_8c.html#a2b1bd24d2eddf8081d8c541e4cc4fd4b',1,'command.c']]],
  ['columns',['COLUMNS',['../screen_8c.html#a06c6c391fc11d106e9909f0401b255b1',1,'screen.c']]]
];
