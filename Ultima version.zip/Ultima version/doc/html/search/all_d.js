var searchData=
[
  ['n',['N',['../types_8h.html#aa268a41a13430b18e933ed40207178d0a2c63acbe79d9f41ba6bb7766e9c37702',1,'types.h']]],
  ['n_5fcmd',['N_CMD',['../command_8c.html#ae180fe89f0ae48ce5c80ffaa18de9271',1,'command.c']]],
  ['name',['name',['../struct__Command.html#a08f9c6b984243b637887e0bf0c50bd7e',1,'_Command::name()'],['../struct__Link.html#a5d81b67643f9c41056d8b199adbed77d',1,'_Link::name()'],['../struct__Object.html#a3dab853826b88558a2c07dec50b96d57',1,'_Object::name()'],['../struct__Player.html#adda99df91c28eb58d392f2b43fc6898f',1,'_Player::name()'],['../struct__Space.html#aa1c9c994c2d16ecf3ef46138685fdfdc',1,'_Space::name()']]],
  ['no_5fcmd',['NO_CMD',['../command_8h.html#ace19ba2296a74e4aef53304e0934c50ca785693a1d550a18688638e9124af41d0',1,'command.h']]],
  ['no_5fid',['NO_ID',['../types_8h.html#a642e16f35aa1e585c25e405ede76e115',1,'types.h']]],
  ['north',['north',['../struct__Space.html#ae5ebe53ce79514d7d2d93911e0159252',1,'_Space']]],
  ['num_5fobj',['num_obj',['../struct__Set.html#a6d4c5bc1c085564602a0e93fe074ad91',1,'_Set']]]
];
