var searchData=
[
  ['gdesc',['gdesc',['../struct__Space.html#af311939768f2208925e07a50ebd3f045',1,'_Space']]]
];
