var searchData=
[
  ['last_5fcmd',['last_cmd',['../struct__Game.html#a27727b50ea0904a1fe9e1c55c27f2cf1',1,'_Game']]],
  ['last_5fdescription_5fasked',['last_description_asked',['../struct__Game.html#a21a6bc2ef3fa5217f45c5f2f966ca143',1,'_Game']]],
  ['last_5froll',['last_roll',['../struct__Die.html#a522e4527bd70cf87afcbabd9d9dede34',1,'_Die']]],
  ['light',['light',['../struct__Object.html#a213da2eaffd083a65a4109f96be560b4',1,'_Object::light()'],['../struct__Space.html#a15f20d8ccdec846b9a4f77464748bff5',1,'_Space::light()']]],
  ['link',['link',['../struct__Game.html#acde062499c7180ecaf3bd36ba64385c6',1,'_Game']]]
];
