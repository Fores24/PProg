var searchData=
[
  ['access',['ACCESS',['../screen_8c.html#a28b37557462b06fbb08e707dc0ba2136',1,'screen.c']]],
  ['area',['Area',['../screen_8h.html#acfdfc42f6522d75fa3c16713afde8127',1,'screen.h']]]
];
